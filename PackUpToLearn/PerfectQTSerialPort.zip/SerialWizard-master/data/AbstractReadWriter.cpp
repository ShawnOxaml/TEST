//
// Created by chang on 2018-03-07.
//

#include "AbstractReadWriter.h"

#include <QTimer>

AbstractReadWriter::AbstractReadWriter(QObject *parent) : QObject(parent) {

}
