#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_serialport = new QSerialPort();
    serialport_init();
    connect(m_serialport,SIGNAL(readyRead()),this,SLOT(receive_data()));
    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(send_data()));
    connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(open_serialport()));



}

bool MainWindow::serialport_init(){
    //获得所有可用端口列表
    QList<QSerialPortInfo> serialPortInfoList = QSerialPortInfo::availablePorts();
    if(serialPortInfoList.isEmpty()){
        return false;
    }
    QList<QSerialPortInfo>::iterator iter = serialPortInfoList.begin();
    //将所有端口添加到界面的下拉列表中
    while(iter!=serialPortInfoList.end()){
        ui->comboBox->addItem(iter->portName());
        iter++;
    }
    return true;
}

void MainWindow::open_serialport(){
    //判断串口开启状态
    if(m_serialport->isOpen()){
        //若串口已经打开，则关闭它，设置指示灯为红色，设置按钮显示“打开串口”
        m_serialport->clear();
        m_serialport->close();
        ui->label->setStyleSheet("background-color:rgb(255,0,0);border-radius:12px;");
        ui->pushButton_2->setText("打开串口");
        return;
    }else{
         //若串口没有打开，则打开选择的串口，设置指示灯为绿色，设置按钮显示“关闭串口”
        m_serialport->setPortName(ui->comboBox->currentText());
        m_serialport->open(QIODevice::ReadWrite);
        m_serialport->setBaudRate(QSerialPort::Baud115200);
        m_serialport->setDataBits(QSerialPort::Data8);
        m_serialport->setParity(QSerialPort::NoParity);
        m_serialport->setStopBits(QSerialPort::OneStop);
        m_serialport->setFlowControl(QSerialPort::NoFlowControl);
        ui->label->setStyleSheet("background-color:rgb(0,255,0);border-radius:12px;");
        ui->pushButton_2->setText("关闭串口");
    }

}

void MainWindow::receive_data(){
    QByteArray message;
    message.append(m_serialport->readAll());
    //使textEdit控件追加显示接收到的数据
    ui->textEdit->append(message);
}

void MainWindow::send_data(){
    QString message = ui->lineEdit->text();
    QByteArray messageSend;
    messageSend.append(message);
    m_serialport->write(messageSend);
}




MainWindow::~MainWindow()
{
    delete ui;
}

