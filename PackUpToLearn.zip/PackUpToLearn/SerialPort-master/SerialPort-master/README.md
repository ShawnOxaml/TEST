# SerialPort
新手练习Qt上位机编程，简单的模仿sscom串口工具
