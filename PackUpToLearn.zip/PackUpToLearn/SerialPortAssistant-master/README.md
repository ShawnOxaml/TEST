# Serial Port Assistant
A simple serial port assistant software make by Qt5
![Image](https://github.com/hubenchang0515/SerialPortAssistant/blob/master/rsc/SerialPortAssistant.png?raw=true)
